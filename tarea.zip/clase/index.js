const { celular } = require('./celular');

const mostrarDescripcion = () => {
  console.log(`Mi celular es un ${celular.marca} ${celular.modelo}, de color ${celular.color}. Tiene ${celular.almacenamiento} de almacenamiento, ${celular.ram} de RAM, y lo compré el ${celular.fechaCompra}.`);
};


mostrarDescripcion();
const celularActualizado = { ...celular, color: 'Azul', almacenamiento: '256GB' };


module.exports = { celular, celularActualizado };
const procesarCelular = (celular, callback) => {
    console.log('Procesando el celular...');
    callback(celular);
  };
  
  
  const mostrarDescripcionCallback = (celular) => {
    console.log(`Descripción: Mi celular actualizado es un ${celular.marca} ${celular.modelo}, color ${celular.color}, con ${celular.almacenamiento} de almacenamiento.`);
  };
  
  
  procesarCelular(celularActualizado, mostrarDescripcionCallback);
  